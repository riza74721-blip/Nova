# Nova Android Sesli Asistan

Android 8+ için ilk **deneysel** sürüm. Türkçe konuşma tanıma (telefonun tanıma hizmeti üzerinden), Türkçe sesli yanıt, saat/tarih, selamlama ve konuşma hızı ayarı içerir.

## APK oluşturma

Bu dosyaları GitHub deposunun köküne yükleyin. **Actions → Android APK → Run workflow** ile derlemeyi başlatın. İşlem başarılı olursa **Nova-debug-apk** adlı artifact'i indirip ZIP'ten APK'yı çıkarın. Android yükleme izni istenebilir.

## Sınırlar

Bu sürüm sürekli arka plan dinlemesi, kilit ekranında "Nova" uyandırma, kişiye özel ses tanıma, telefon kontrolü veya yapay zekâ API bağlantısı **içermez**. Mikrofon sadece kullanıcı butona bastığında açılır. Bazı cihazlarda konuşma tanıma için Google hizmeti/internet gerekebilir. Kaynak kodu test amacıyla hazırlanmıştır; APK derlemesi henüz doğrulanmamıştır.
